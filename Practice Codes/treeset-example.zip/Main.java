import java.util.*;
class NumberSort implements Comparator<String>{
    @Override
    public int compare(String a , String b){
        return a.compareTo(b);
    }
}
public class Main{
    public static void main(String[]args){
        TreeSet <String> obj=new TreeSet<>(new NumberSort());
        obj.add("Hi");
        obj.add("Baa");
        obj.add("Reii");
        obj.add("Cooo");
        System.out.println(obj);
        
        
        
    }
}