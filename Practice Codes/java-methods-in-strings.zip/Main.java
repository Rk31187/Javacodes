public class Main{
    public static void main(String[]args){
        String s = "RAMAKRISHNA";
        System.out.println(s.length());
        System.out.println(s.indexOf('A'));
        System.out.println(s.indexOf('A'));

        
         System.out.println(s.contains("VT"));
        System.out.println(s.endsWith("V"));
        System.out.println(s.toLowerCase());
        System.out.println(s.toUpperCase());
        //if we want to compare the two strings then we can use the s.equals
        String s1="ramakrishna";
        System.out.println(s.equals(s1));


         


    }
}