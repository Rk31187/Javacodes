import java.util.*;
public class Main{
    public static void main(String[]args){
        ArrayList<String> obj=new ArrayList<>();
        obj.add("Ram");
        obj.add("Abhi");
        obj.add("Revda");
        obj.add("Mani");
        obj.add("Ram");
        System.out.println("Now we will Reverse the order");
        ListIterator<String> list1=obj.listIterator(obj.size());
        while(list1.hasPrevious()){
            String str=list1.previous();
            System.out.println(str);
        }
        for(int i=0;i<obj.size();i++){
            System.out.println(obj.get(i));
            
        }

    } 
}