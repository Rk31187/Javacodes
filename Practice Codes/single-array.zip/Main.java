import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        int arr[]=new int[6];
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<6;i++){
          System.out.println("Enter the Marks of Student"+(i+1));

            arr[i] = sc.nextInt();
        }
        for(int i=0;i<6;i++){
            System.out.println(arr[i]+ " ");
        }
        
    }
}