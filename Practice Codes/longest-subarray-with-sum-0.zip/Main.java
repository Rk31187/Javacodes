/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String args[])
    {
        int d1[] = {15, -2, 2, -8, 1, 7, 10, 23};
        int nums = d1.length;
        HashMap<Integer,Integer>d2=new HashMap<>();
        int sum=0 ;
        int max_length=0; 
        for (int i=0;i<nums;i++){
            sum=sum+d1[i];
            if(d2.containsKey(sum)){
                int index=d2.get(sum);
                max_length=Math.max(max_length,i-index);
            }
            else {
                d2.put(sum,i);
            }
        }
        System.out.println(max_length);
    }
}
