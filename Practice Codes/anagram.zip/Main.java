/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
public class Main Arrays 
{
	public static void main(String[] args) 
	{
	    String a= "anagram";
        String b= "margana";
        char x[]= a.toCharArray();
        char y[]= b.toCharArray();
        Arrays.sort(a);
        Arrays.sort(b);
        boolean result = Arrays. equals(a,b);
        if(result==true)
        {
            System.out.println("Strings are anagram");
            
        }
         else 
         {
              
             System.out.println("Strings are not anagram");
            
         }
	}
}
