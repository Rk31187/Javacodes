import java.util.*;
public class Main{
    public static void main(String[]args){
        ArrayList<String> obj=new ArrayList<>();
        obj.add("Mango");
        obj.add("Apple");
        obj.add("Orange");
        obj.add("Guava");
        obj.add("Banana");
        Collections.sort(obj);
        for(String Fruit:obj){
            System.out.println(Fruit);
        }
        System.out.println("Sorting numbers.....");
        
        ArrayList<Integer> obj1=new ArrayList<>();
        obj1.add(22);
        obj1.add(2);
        obj1.add(11);
        obj1.add(10);
        obj1.add(23);
        Collections.sort(obj1);
        for(Integer Numbers:obj1){
            System.out.println(Numbers);
        }


        
    }
}