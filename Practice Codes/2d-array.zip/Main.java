import java.util.Scanner;
public class Main{
    public static void main(String[]args){
        int arr[][]=new int[4][6];
        Scanner sc=new Scanner(System.in);
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                System.out.println("Enter the Marks in row "+(i+1)+ " and colums " +(j+1));
                arr[i][j]=sc.nextInt();
            }
        }
        for(int i=0;i<2;i++){
            for(int j=0;j<3;j++){
                System.out.println(arr[i][j]+ " ");
            }
            System.out.println(" ");
        }
        
    }
}