/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args)
	{
	  String arr[]={"ram","eswar","abhi","ram"};
	  boolean flag=false;
	   
	   for(int i=0;i<=arr.length;i++)
	   {
	       for(int j=i+1;j<=arr.length;j++)
	        {
	         
	        
	           if(arr[i]==arr[j])
	           {
	           System.out.println("found the duplicate:"+arr[i]);
	            flag=true ;
	           }
	        }
	   }     
	   
	      if (flag==false)
	      {
	          System.out.println(" not found the duplicate:");
	           
	      }
	}
}

