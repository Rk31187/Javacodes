import java.util.*;
public class Main{
    public static void main(String[]args){
        ArrayList<String> obj=new ArrayList<>();
        obj.add("Telugu");
        obj.add("Hindi");
        obj.add("Tamil");
        obj.add("Malayalam");
        obj.add(2,"Kannada");//replacing the index
        System.out.println("USing ArrayList");
        Iterator lang=obj. iterator();//itearor checks the if the next number in the arrylist
        //observe I must be capital 
        while(lang.hasNext()){
            System.out.println(lang.next());
        }
    //now we will write as same as for the LinkedList
        LinkedList<String> obj1=new LinkedList<>();
        obj1.add("Telugu");
        obj1.add("Hindi");
        obj1.add("Tamil");
        obj1.add("Malayalam");
        obj1.add(2,"Islam");
        Iterator lang1=obj1.iterator();
        System.out.println("Using LinkedList");
        while(lang1.hasNext()){
            System.out.println(lang1.next());
        }
    //now we will write as same as for the LinkedList
    //in linkedlist multithreading can occur but it is not possible in vector

       Vector<String> obj2=new Vector<>();
        obj2.add("Telugu");
        obj2.add("Hindi");
        obj2.add("Tamil");
        obj2.add("Malayalam");
        obj2.add(2,"Christ");
        Iterator lang2=obj1.iterator();
        System.out.println("Using Vector");
        while(lang2.hasNext()){
            System.out.println(lang2.next());
    }
  }
}